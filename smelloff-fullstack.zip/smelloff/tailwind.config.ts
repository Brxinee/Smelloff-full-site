/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        acid:  '#b8ff57',
        ink:   '#0a0a0a',
        steel: '#1a1a1a',
        ash:   '#2e2e2e',
        mist:  '#888888',
      },
      fontFamily: {
        display: ['var(--font-barlow)', 'sans-serif'],
        body:    ['var(--font-syne)',   'sans-serif'],
      },
    },
  },
  plugins: [],
};
