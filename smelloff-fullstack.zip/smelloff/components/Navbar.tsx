'use client';
import Link from 'next/link';
import { SignInButton, SignUpButton, UserButton, useUser } from '@clerk/nextjs';

export default function Navbar() {
  const { isSignedIn } = useUser();

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-4 border-b border-ash/50 bg-ink/80 backdrop-blur-md">
      <Link href="/" className="font-display font-800 text-2xl tracking-widest uppercase text-white">
        SMELL<span className="text-acid">OFF</span>
      </Link>

      <div className="hidden md:flex items-center gap-8 text-sm font-body text-mist uppercase tracking-widest">
        <Link href="/#benefits" className="hover:text-white transition-colors">Why it works</Link>
        <Link href="/shop" className="hover:text-white transition-colors">Shop</Link>
        <Link href="/#ai" className="hover:text-white transition-colors">Find yours</Link>
      </div>

      <div className="flex items-center gap-3">
        {isSignedIn ? (
          <>
            <Link href="/account" className="text-sm text-mist hover:text-white transition-colors font-body uppercase tracking-widest">
              Orders
            </Link>
            <UserButton afterSignOutUrl="/" />
          </>
        ) : (
          <>
            <SignInButton mode="modal">
              <button className="text-sm text-mist hover:text-white transition-colors font-body uppercase tracking-widest">
                Sign in
              </button>
            </SignInButton>
            <SignUpButton mode="modal">
              <button className="px-4 py-2 bg-acid text-ink text-sm font-display font-700 uppercase tracking-widest hover:bg-white transition-colors">
                Get Early Access
              </button>
            </SignUpButton>
          </>
        )}
      </div>
    </nav>
  );
}
