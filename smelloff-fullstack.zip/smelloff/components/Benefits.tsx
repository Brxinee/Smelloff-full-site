'use client';
import { motion } from 'framer-motion';

const benefits = [
  { icon: '⚗️', title: 'Zinc Ricinoleate', body: 'Neutralises odour molecules chemically. Not fragrance cover-up — actual elimination.' },
  { icon: '🧴', title: 'Niacinamide + Aloe', body: 'Calms skin, reduces irritation, keeps underarms healthy long-term.' },
  { icon: '⚡', title: 'pH 4.5–5.5', body: 'Skin-pH matched. No dryness. No disruption. Works with your skin biology.' },
  { icon: '💧', title: '48% Denatured Ethanol', body: 'Fast-absorbing antibacterial base. Kills odour-causing bacteria on contact.' },
  { icon: '🌿', title: 'Panthenol + Glycerin', body: 'Hydrates while it works. You won\'t feel sticky. You will feel clean.' },
  { icon: '🇮🇳', title: 'Made for India', body: 'Formulated for Indian heat, sweat, and skin. Not a Western formula rebranded.' },
];

export default function Benefits() {
  return (
    <section id="benefits" className="bg-steel py-32 px-6">
      <div className="max-w-6xl mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="font-display font-800 uppercase text-white text-center leading-none mb-4"
          style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}
        >
          Why ODORSTRIKE<br />
          <span className="text-acid">Actually Works</span>
        </motion.h2>
        <p className="text-center text-mist font-body mb-20 max-w-xl mx-auto">
          Every ingredient earns its place. No filler. No fluff.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-ash">
          {benefits.map((b, i) => (
            <motion.div
              key={b.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="bg-steel p-10 group hover:bg-ink transition-colors duration-300"
            >
              <div className="text-4xl mb-6">{b.icon}</div>
              <h3 className="font-display font-700 uppercase text-white text-2xl tracking-wide mb-3 group-hover:text-acid transition-colors">
                {b.title}
              </h3>
              <p className="font-body text-mist text-sm leading-relaxed">{b.body}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
