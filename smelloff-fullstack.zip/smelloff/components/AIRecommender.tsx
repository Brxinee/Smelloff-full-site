'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const questions = [
  { id: 'activity', label: 'Your day usually involves:', options: ['Office/desk work', 'Outdoor fieldwork', 'Gym / heavy workouts', 'Mixed daily'] },
  { id: 'concern', label: 'Biggest odour concern:', options: ['Underarms', 'Body post-gym', 'All-day freshness', 'Post-sweat reapply'] },
  { id: 'skin',     label: 'Your skin type:', options: ['Dry', 'Oily', 'Sensitive', 'Combination'] },
];

export default function AIRecommender() {
  const [step, setStep]         = useState(0);
  const [answers, setAnswers]   = useState<Record<string, string>>({});
  const [result, setResult]     = useState<string | null>(null);
  const [loading, setLoading]   = useState(false);

  const current = questions[step];

  async function handleSelect(value: string) {
    const updated = { ...answers, [current.id]: value };
    setAnswers(updated);

    if (step < questions.length - 1) {
      setStep(step + 1);
    } else {
      // All answered → call AI recommendation endpoint
      setLoading(true);
      try {
        const res = await fetch('/api/recommend', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(updated),
        });
        const data = await res.json();
        setResult(data.recommendation);
      } catch {
        setResult('ODORSTRIKE 50ml — works for your profile. Grab it.');
      } finally {
        setLoading(false);
      }
    }
  }

  function reset() {
    setStep(0);
    setAnswers({});
    setResult(null);
  }

  return (
    <section id="ai" className="bg-steel py-32 px-6">
      <div className="max-w-2xl mx-auto text-center">
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="font-body text-acid uppercase tracking-[0.4em] text-sm mb-4"
        >
          AI-Powered
        </motion.p>
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="font-display font-800 uppercase text-white leading-none mb-16"
          style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}
        >
          Find Your<br /><span className="text-acid">Perfect Match</span>
        </motion.h2>

        <AnimatePresence mode="wait">
          {!result ? (
            <motion.div
              key={`step-${step}`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <div className="text-mist font-body text-xs uppercase tracking-widest mb-2">
                {step + 1} / {questions.length}
              </div>
              <h3 className="font-display font-700 text-white text-3xl uppercase tracking-wide">
                {current.label}
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {current.options.map(opt => (
                  <button
                    key={opt}
                    onClick={() => handleSelect(opt)}
                    className="p-5 border border-ash text-white font-body text-sm hover:border-acid hover:text-acid hover:bg-acid/5 transition-all text-left"
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="result"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="border border-acid/50 p-10 bg-acid/5 acid-glow"
            >
              {loading ? (
                <p className="text-acid font-body animate-pulse">Analysing your profile…</p>
              ) : (
                <>
                  <p className="text-acid font-body text-xs uppercase tracking-widest mb-4">Your recommendation</p>
                  <p className="text-white font-body text-lg leading-relaxed">{result}</p>
                  <div className="flex gap-3 mt-8 justify-center">
                    <a
                      href="/shop"
                      className="px-8 py-3 bg-acid text-ink font-display font-700 uppercase tracking-widest hover:bg-white transition-colors"
                    >
                      Buy Now
                    </a>
                    <button
                      onClick={reset}
                      className="px-8 py-3 border border-ash text-mist font-display uppercase tracking-widest hover:border-white hover:text-white transition-colors"
                    >
                      Retake
                    </button>
                  </div>
                </>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
