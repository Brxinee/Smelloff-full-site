import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-steel border-t border-ash px-6 py-16">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-start gap-10">
        <div>
          <p className="font-display font-800 text-2xl uppercase tracking-widest text-white mb-2">
            SMELL<span className="text-acid">OFF</span>
          </p>
          <p className="font-body text-mist text-sm max-w-xs">
            ODORSTRIKE — India's sharpest men's odour-control mist. Science-backed. Street-approved.
          </p>
        </div>
        <div className="flex gap-16 text-sm font-body text-mist uppercase tracking-widest">
          <div className="flex flex-col gap-3">
            <Link href="/shop"    className="hover:text-white transition-colors">Shop</Link>
            <Link href="/#ai"     className="hover:text-white transition-colors">Find Yours</Link>
            <Link href="/account" className="hover:text-white transition-colors">Orders</Link>
          </div>
          <div className="flex flex-col gap-3">
            <a href="mailto:hello@smelloff.in" className="hover:text-white transition-colors">Contact</a>
            <a href="https://instagram.com/smelloff.in" className="hover:text-white transition-colors">Instagram</a>
          </div>
        </div>
      </div>
      <div className="max-w-6xl mx-auto mt-12 pt-8 border-t border-ash flex flex-col md:flex-row justify-between items-center gap-4">
        <p className="font-body text-mist/40 text-xs uppercase tracking-widest">
          © {new Date().getFullYear()} Smelloff. All rights reserved.
        </p>
        <p className="font-body text-mist/40 text-xs uppercase tracking-widest">
          Made in Hyderabad 🇮🇳
        </p>
      </div>
    </footer>
  );
}
