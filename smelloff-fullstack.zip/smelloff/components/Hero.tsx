'use client';
import { motion } from 'framer-motion';
import Link from 'next/link';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden bg-ink px-6 pt-24">
      {/* Background grid */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: 'linear-gradient(#b8ff5720 1px, transparent 1px), linear-gradient(90deg, #b8ff5720 1px, transparent 1px)',
          backgroundSize: '60px 60px',
        }}
      />

      {/* Glow blob */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-acid/5 blur-[120px] pointer-events-none" />

      <div className="relative z-10 text-center max-w-5xl">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="font-body text-acid uppercase tracking-[0.4em] text-sm mb-6"
        >
          India's first Zinc Ricinoleate body mist
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="font-display font-800 uppercase text-white leading-none"
          style={{ fontSize: 'clamp(4rem, 14vw, 11rem)' }}
        >
          SMELL LIKE<br />
          <span className="text-acid">YOU MEAN IT</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
          className="font-body text-mist text-lg mt-8 max-w-2xl mx-auto leading-relaxed"
        >
          Kill odour at the source — not with cheap fragrance, but with science.
          ODORSTRIKE neutralises molecules, not masks them. pH-matched. Skin-safe. Built for India.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-12"
        >
          <Link
            href="/shop"
            className="px-10 py-4 bg-acid text-ink font-display font-700 text-xl uppercase tracking-widest hover:bg-white transition-colors acid-glow"
          >
            Shop Now — ₹299
          </Link>
          <Link
            href="/#waitlist"
            className="px-10 py-4 border border-ash text-white font-display font-700 text-xl uppercase tracking-widest hover:border-acid hover:text-acid transition-colors"
          >
            Join Waitlist
          </Link>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="font-body text-mist/60 text-xs mt-6 uppercase tracking-widest"
        >
          Pilot batch · 50 units · Ships Hyderabad first
        </motion.p>
      </div>

      {/* Scroll hint */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <span className="font-body text-mist/40 text-xs uppercase tracking-widest">Scroll</span>
        <div className="w-px h-12 bg-gradient-to-b from-acid/40 to-transparent" />
      </motion.div>
    </section>
  );
}
