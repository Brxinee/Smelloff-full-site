'use client';
import { useState } from 'react';
import { motion } from 'framer-motion';

export default function WaitlistSection() {
  const [email,   setEmail]   = useState('');
  const [status,  setStatus]  = useState<'idle' | 'loading' | 'done' | 'error'>('idle');
  const [message, setMessage] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email) return;
    setStatus('loading');
    try {
      const res = await fetch('/api/waitlist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (res.ok) {
        setStatus('done');
        setMessage(data.message || 'You\'re on the list. We\'ll hit you when stock drops.');
      } else {
        setStatus('error');
        setMessage(data.error || 'Something went wrong. Try again.');
      }
    } catch {
      setStatus('error');
      setMessage('Network error. Try again.');
    }
  }

  return (
    <section id="waitlist" className="bg-ink py-32 px-6 border-t border-ash">
      <div className="max-w-2xl mx-auto text-center">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="font-display font-800 uppercase text-white leading-none mb-4"
          style={{ fontSize: 'clamp(2.5rem, 6vw, 4.5rem)' }}
        >
          Pilot batch.<br />
          <span className="text-acid">50 units only.</span>
        </motion.h2>
        <p className="font-body text-mist mb-12 max-w-md mx-auto">
          Get notified first. Early access gets a launch discount and free shipping in Hyderabad.
        </p>

        {status === 'done' ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="border border-acid/50 p-8 bg-acid/5"
          >
            <p className="text-acid font-display font-700 text-2xl uppercase tracking-wide mb-2">You're in.</p>
            <p className="text-mist font-body text-sm">{message}</p>
          </motion.div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
            <input
              type="email"
              required
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="your@email.com"
              className="flex-1 px-6 py-4 bg-steel border border-ash text-white font-body placeholder:text-mist/50 focus:outline-none focus:border-acid transition-colors"
            />
            <button
              type="submit"
              disabled={status === 'loading'}
              className="px-8 py-4 bg-acid text-ink font-display font-700 uppercase tracking-widest hover:bg-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
            >
              {status === 'loading' ? 'Joining…' : 'Get Early Access'}
            </button>
          </form>
        )}

        {status === 'error' && (
          <p className="text-red-400 font-body text-sm mt-4">{message}</p>
        )}

        <p className="font-body text-mist/40 text-xs mt-6 uppercase tracking-widest">
          No spam. One email when stock is live.
        </p>
      </div>
    </section>
  );
}
