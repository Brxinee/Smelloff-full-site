'use client';
import { motion } from 'framer-motion';

const rows = [
  { feature: 'Odour neutralisation',    smelloff: true,  deos: false, febreze: false },
  { feature: 'Zinc Ricinoleate',         smelloff: true,  deos: false, febreze: false },
  { feature: 'Skin pH matched',          smelloff: true,  deos: false, febreze: false },
  { feature: 'No aluminium/parabens',    smelloff: true,  deos: false, febreze: true  },
  { feature: 'Non-aerosol (eco-safe)',   smelloff: true,  deos: false, febreze: false },
  { feature: 'Under ₹300',              smelloff: true,  deos: true,  febreze: false },
  { feature: 'Made for Indian sweat',    smelloff: true,  deos: false, febreze: false },
];

const Check = () => <span className="text-acid font-display font-800 text-xl">✓</span>;
const Cross = () => <span className="text-mist/40 font-display text-xl">✕</span>;

export default function ComparisonTable() {
  return (
    <section className="bg-ink py-32 px-6">
      <div className="max-w-4xl mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="font-display font-800 uppercase text-white text-center leading-none mb-20"
          style={{ fontSize: 'clamp(2.5rem, 6vw, 4.5rem)' }}
        >
          vs. <span className="text-acid">Everything Else</span>
        </motion.h2>

        <div className="border border-ash overflow-hidden">
          {/* Header */}
          <div className="grid grid-cols-4 bg-ash/50">
            <div className="p-4 font-body text-xs text-mist uppercase tracking-widest">Feature</div>
            <div className="p-4 text-center font-display font-700 text-acid uppercase tracking-widest text-sm">ODORSTRIKE</div>
            <div className="p-4 text-center font-display font-700 text-mist uppercase tracking-widest text-sm">Regular Deos</div>
            <div className="p-4 text-center font-display font-700 text-mist uppercase tracking-widest text-sm">Febreze</div>
          </div>

          {rows.map((row, i) => (
            <motion.div
              key={row.feature}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.06 }}
              className={`grid grid-cols-4 border-t border-ash/50 ${i % 2 === 0 ? 'bg-steel/30' : ''}`}
            >
              <div className="p-4 font-body text-sm text-white/80">{row.feature}</div>
              <div className="p-4 text-center">{row.smelloff ? <Check /> : <Cross />}</div>
              <div className="p-4 text-center">{row.deos    ? <Check /> : <Cross />}</div>
              <div className="p-4 text-center">{row.febreze ? <Check /> : <Cross />}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
