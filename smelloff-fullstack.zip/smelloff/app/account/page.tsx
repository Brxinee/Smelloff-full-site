import { currentUser } from '@clerk/nextjs/server';
import { redirect } from 'next/navigation';
import { supabaseAdmin } from '@/lib/supabase';

export default async function AccountPage() {
  const user = await currentUser();
  if (!user) redirect('/sign-in');

  const { data: orders } = await supabaseAdmin
    .from('orders')
    .select('*')
    .eq('clerk_user_id', user.id)
    .order('created_at', { ascending: false });

  return (
    <main className="min-h-screen bg-ink pt-24 px-6">
      <div className="max-w-3xl mx-auto py-20">
        <h1 className="font-display font-800 uppercase text-white text-5xl leading-none mb-2">
          Your <span className="text-acid">Orders</span>
        </h1>
        <p className="font-body text-mist text-sm mb-16 uppercase tracking-widest">
          {user.emailAddresses[0].emailAddress}
        </p>

        {!orders || orders.length === 0 ? (
          <div className="border border-ash p-16 text-center">
            <p className="font-body text-mist mb-6">No orders yet.</p>
            <a
              href="/shop"
              className="px-8 py-4 bg-acid text-ink font-display font-700 uppercase tracking-widest hover:bg-white transition-colors"
            >
              Shop Now
            </a>
          </div>
        ) : (
          <div className="space-y-px">
            {orders.map((order: any) => (
              <div key={order.id} className="grid grid-cols-3 gap-4 border border-ash p-6 bg-steel/20 hover:bg-steel/40 transition-colors">
                <div>
                  <p className="font-body text-mist text-xs uppercase tracking-widest mb-1">Order</p>
                  <p className="font-display font-700 text-white text-lg uppercase">
                    #{order.stripe_session_id?.slice(-8).toUpperCase()}
                  </p>
                </div>
                <div>
                  <p className="font-body text-mist text-xs uppercase tracking-widest mb-1">Amount</p>
                  <p className="font-display font-700 text-acid text-lg">₹{order.amount}</p>
                </div>
                <div>
                  <p className="font-body text-mist text-xs uppercase tracking-widest mb-1">Status</p>
                  <span className="px-2 py-1 bg-acid/20 text-acid font-body text-xs uppercase tracking-widest">
                    {order.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
