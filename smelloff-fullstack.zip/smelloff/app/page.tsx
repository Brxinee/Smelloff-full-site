'use client';
import Hero from '@/components/Hero';
import Benefits from '@/components/Benefits';
import ComparisonTable from '@/components/ComparisonTable';
import AIRecommender from '@/components/AIRecommender';
import WaitlistSection from '@/components/WaitlistSection';
import Footer from '@/components/Footer';

export default function HomePage() {
  return (
    <main>
      <Hero />
      <Benefits />
      <ComparisonTable />
      <AIRecommender />
      <WaitlistSection />
      <Footer />
    </main>
  );
}
