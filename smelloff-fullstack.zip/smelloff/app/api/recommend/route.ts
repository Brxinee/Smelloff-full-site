import { NextRequest, NextResponse } from 'next/server';
import { Pinecone } from '@pinecone-database/pinecone';
import OpenAI from 'openai';

const pinecone = new Pinecone({ apiKey: process.env.PINECONE_API_KEY! });
const openai   = new OpenAI({ apiKey: process.env.OPENAI_API_KEY! });

export async function POST(req: NextRequest) {
  try {
    const answers: Record<string, string> = await req.json();
    const query = `Activity: ${answers.activity}. Concern: ${answers.concern}. Skin type: ${answers.skin}.`;

    // Generate embedding for the user's profile
    const embeddingRes = await openai.embeddings.create({
      model: 'text-embedding-3-small',
      input: query,
    });
    const vector = embeddingRes.data[0].embedding;

    // Query Pinecone for best matching product/variant
    const index   = pinecone.index(process.env.PINECONE_INDEX!);
    const results = await index.query({
      vector,
      topK: 1,
      includeMetadata: true,
    });

    const top = results.matches?.[0];
    if (top?.metadata?.recommendation) {
      return NextResponse.json({ recommendation: top.metadata.recommendation as string });
    }

    // Fallback: rule-based recommendation
    const recommendation = buildFallbackRecommendation(answers);
    return NextResponse.json({ recommendation });

  } catch (err) {
    console.error('[recommend]', err);
    // Always return something useful
    return NextResponse.json({
      recommendation: 'ODORSTRIKE 50ml — the original formula. Perfect for all-day odour control. Grab one.',
    });
  }
}

function buildFallbackRecommendation(answers: Record<string, string>): string {
  const { activity, concern, skin } = answers;

  if (activity?.includes('Gym') || concern?.includes('gym')) {
    return 'ODORSTRIKE 50ml — the post-gym formula hits hardest for you. Apply right after your shower, focus on underarms and chest. You\'ll stay clean for 10–12 hours.';
  }
  if (skin?.includes('Sensitive')) {
    return 'ODORSTRIKE 50ml — Niacinamide + Aloe Vera combo is exactly what sensitive skin needs. No irritation. Full odour kill. Apply 15cm away from skin.';
  }
  if (activity?.includes('Office')) {
    return 'ODORSTRIKE 50ml — one morning spray lasts your full work day. Zinc Ricinoleate keeps you neutral even through back-to-back meetings.';
  }
  return 'ODORSTRIKE 50ml — built for your profile. Science-backed odour neutralisation, all day. ₹299. Worth every rupee.';
}
