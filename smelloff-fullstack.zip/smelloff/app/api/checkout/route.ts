import { NextRequest, NextResponse } from 'next/server';
import { stripe } from '@/lib/stripe';
import { currentUser } from '@clerk/nextjs/server';

export async function POST(req: NextRequest) {
  try {
    const user     = await currentUser();
    const { quantity = 1 } = await req.json();

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      line_items: [
        {
          price: process.env.NEXT_PUBLIC_PRODUCT_PRICE_ID!,
          quantity,
        },
      ],
      customer_email: user?.emailAddresses?.[0]?.emailAddress,
      metadata: {
        clerk_user_id: user?.id ?? 'guest',
      },
      success_url: `${process.env.NEXT_PUBLIC_APP_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url:  `${process.env.NEXT_PUBLIC_APP_URL}/shop`,
      billing_address_collection: 'required',
      shipping_address_collection: {
        allowed_countries: ['IN'],
      },
      phone_number_collection: { enabled: true },
      custom_text: {
        submit: { message: 'Ships from Hyderabad in 2–3 business days.' },
      },
    });

    return NextResponse.json({ sessionId: session.id });
  } catch (err) {
    console.error('[checkout]', err);
    return NextResponse.json({ error: 'Checkout failed' }, { status: 500 });
  }
}
