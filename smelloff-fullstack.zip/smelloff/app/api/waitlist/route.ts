import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase';
import { sendWaitlistConfirmation } from '@/lib/resend';

export async function POST(req: NextRequest) {
  try {
    const { email } = await req.json();
    if (!email) return NextResponse.json({ error: 'Email required' }, { status: 400 });

    // Check duplicate
    const { data: existing } = await supabaseAdmin
      .from('waitlist')
      .select('id')
      .eq('email', email)
      .single();

    if (existing) {
      return NextResponse.json({ message: 'Already on the list. We got you.' });
    }

    // Insert
    const { error } = await supabaseAdmin
      .from('waitlist')
      .insert({ email, source: 'landing_page', created_at: new Date().toISOString() });

    if (error) throw error;

    // Send confirmation email
    await sendWaitlistConfirmation(email);

    return NextResponse.json({ message: 'You\'re on the list. We\'ll hit you when stock drops.' });
  } catch (err) {
    console.error('[waitlist]', err);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}
