import { NextRequest, NextResponse } from 'next/server';
import { stripe } from '@/lib/stripe';
import { supabaseAdmin } from '@/lib/supabase';
import { sendOrderConfirmation } from '@/lib/resend';
import Stripe from 'stripe';

export const config = { api: { bodyParser: false } };

export async function POST(req: NextRequest) {
  const body      = await req.text();
  const signature = req.headers.get('stripe-signature')!;

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch (err) {
    console.error('[webhook] signature failed', err);
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object as Stripe.Checkout.Session;

    const orderData = {
      stripe_session_id: session.id,
      clerk_user_id:     session.metadata?.clerk_user_id ?? null,
      email:             session.customer_email,
      amount:            (session.amount_total ?? 0) / 100,
      currency:          session.currency,
      status:            'paid',
      shipping_address:  JSON.stringify(session.shipping_details?.address ?? {}),
      created_at:        new Date().toISOString(),
    };

    // Persist order
    const { error } = await supabaseAdmin.from('orders').insert(orderData);
    if (error) console.error('[webhook] db insert failed', error);

    // Send confirmation email
    if (session.customer_email) {
      await sendOrderConfirmation(session.customer_email, {
        orderId:  session.id.slice(-8).toUpperCase(),
        product:  'ODORSTRIKE 50ml',
        amount:   orderData.amount,
      });
    }
  }

  return NextResponse.json({ received: true });
}
