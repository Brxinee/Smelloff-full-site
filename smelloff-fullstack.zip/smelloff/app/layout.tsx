import type { Metadata } from 'next';
import { ClerkProvider } from '@clerk/nextjs';
import { Barlow_Condensed, Syne } from 'next/font/google';
import './globals.css';
import Navbar from '@/components/Navbar';

const barlow = Barlow_Condensed({
  subsets: ['latin'],
  weight: ['400', '600', '700', '800'],
  variable: '--font-barlow',
});
const syne = Syne({
  subsets: ['latin'],
  weight: ['400', '500', '700'],
  variable: '--font-syne',
});

export const metadata: Metadata = {
  title: 'ODORSTRIKE by Smelloff — Smell Like You Mean It',
  description: 'India\'s first Zinc Ricinoleate body mist. Kill odour at the source. No gas. No nonsense.',
  openGraph: {
    title: 'ODORSTRIKE — Smell Like You Mean It',
    description: 'India\'s sharpest men\'s odour-control mist. Science-backed. Street-approved.',
    url: 'https://smelloff.in',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="en" className={`${barlow.variable} ${syne.variable}`}>
        <body>
          <Navbar />
          {children}
        </body>
      </html>
    </ClerkProvider>
  );
}
