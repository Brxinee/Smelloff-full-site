'use client';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { loadStripe } from '@stripe/stripe-js';

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!);

const product = {
  name: 'ODORSTRIKE',
  subtitle: 'Men\'s Body Odour Control Mist',
  price: 299,
  mrp: 399,
  volume: '50ml',
  description: 'Zinc Ricinoleate + Niacinamide + Aloe Vera. pH-matched for Indian skin. Non-aerosol. Kills odour molecules — doesn\'t just cover them.',
  bullets: [
    '12-hour odour neutralisation',
    'Antibacterial + skin-soothing',
    'No aluminium chlorohydrate',
    'No parabens',
    'Non-aerosol — TSA safe',
    'Made in Hyderabad',
  ],
};

export default function ShopPage() {
  const [loading, setLoading] = useState(false);

  async function handleCheckout() {
    setLoading(true);
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ quantity: 1 }),
      });
      const { sessionId } = await res.json();
      const stripe = await stripePromise;
      await stripe?.redirectToCheckout({ sessionId });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-ink pt-24 px-6">
      <div className="max-w-5xl mx-auto py-20">
        <div className="grid md:grid-cols-2 gap-16 items-start">

          {/* Product visual */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            className="aspect-square bg-steel border border-ash flex items-center justify-center relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-acid/5 to-transparent" />
            <div className="text-center z-10">
              <p className="font-display font-800 text-acid text-6xl uppercase tracking-widest">ODR</p>
              <p className="font-display font-700 text-white text-2xl uppercase tracking-widest mt-2">STRIKE</p>
              <p className="font-body text-mist text-sm mt-4">50ml</p>
            </div>
            {/* Pilot badge */}
            <div className="absolute top-6 right-6 px-3 py-1 bg-acid text-ink font-display font-700 text-xs uppercase tracking-widest">
              Pilot Batch
            </div>
          </motion.div>

          {/* Product details */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div>
              <p className="font-body text-mist uppercase tracking-widest text-xs mb-2">{product.subtitle}</p>
              <h1 className="font-display font-800 uppercase text-white text-6xl leading-none">{product.name}</h1>
            </div>

            <div className="flex items-baseline gap-4">
              <span className="font-display font-700 text-acid text-4xl">₹{product.price}</span>
              <span className="font-body text-mist text-xl line-through">₹{product.mrp}</span>
              <span className="px-2 py-1 bg-acid/20 text-acid font-body text-xs uppercase tracking-widest">
                {Math.round((1 - product.price / product.mrp) * 100)}% off
              </span>
            </div>

            <p className="font-body text-mist/80 text-sm leading-relaxed">{product.description}</p>

            <ul className="space-y-2">
              {product.bullets.map(b => (
                <li key={b} className="flex items-center gap-3 font-body text-sm text-white/80">
                  <span className="text-acid text-xs">✓</span> {b}
                </li>
              ))}
            </ul>

            <button
              onClick={handleCheckout}
              disabled={loading}
              className="w-full py-5 bg-acid text-ink font-display font-700 text-xl uppercase tracking-widest hover:bg-white transition-colors acid-glow disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Redirecting…' : `Buy Now — ₹${product.price}`}
            </button>

            <p className="font-body text-mist/40 text-xs text-center uppercase tracking-widest">
              Secure checkout via Stripe · Ships from Hyderabad
            </p>
          </motion.div>
        </div>
      </div>
    </main>
  );
}
