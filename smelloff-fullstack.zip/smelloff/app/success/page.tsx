'use client';
import { motion } from 'framer-motion';
import Link from 'next/link';

export default function SuccessPage() {
  return (
    <main className="min-h-screen bg-ink flex items-center justify-center px-6">
      <div className="max-w-xl text-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', stiffness: 200 }}
          className="w-24 h-24 rounded-full bg-acid/20 border border-acid/50 flex items-center justify-center mx-auto mb-10"
        >
          <span className="text-acid text-4xl">✓</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="font-display font-800 uppercase text-white leading-none mb-4"
          style={{ fontSize: 'clamp(3rem, 8vw, 5rem)' }}
        >
          Order<br /><span className="text-acid">Confirmed.</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="font-body text-mist mb-10 leading-relaxed"
        >
          ODORSTRIKE is on its way. Check your email for confirmation.
          Ships from Hyderabad in 2–3 business days.
        </motion.p>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <Link
            href="/account"
            className="px-8 py-4 bg-acid text-ink font-display font-700 uppercase tracking-widest hover:bg-white transition-colors"
          >
            View Orders
          </Link>
          <Link
            href="/"
            className="px-8 py-4 border border-ash text-mist font-display uppercase tracking-widest hover:border-white hover:text-white transition-colors"
          >
            Back Home
          </Link>
        </motion.div>
      </div>
    </main>
  );
}
