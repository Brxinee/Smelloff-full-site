/**
 * Run once: npx ts-node scripts/seed-pinecone.ts
 * Seeds ODORSTRIKE product knowledge into Pinecone for AI recommender
 */
import { Pinecone } from '@pinecone-database/pinecone';
import OpenAI from 'openai';
import * as dotenv from 'dotenv';
dotenv.config({ path: '.env.local' });

const pinecone = new Pinecone({ apiKey: process.env.PINECONE_API_KEY! });
const openai   = new OpenAI({ apiKey: process.env.OPENAI_API_KEY! });

const profiles = [
  {
    id: 'gym-oily',
    text: 'Activity: Gym / heavy workouts. Concern: Body post-gym. Skin type: Oily.',
    recommendation: 'ODORSTRIKE 50ml — formulated for exactly this. Apply post-shower on underarms and chest. Zinc Ricinoleate kills gym-sweat odour at the molecular level. You\'ll stay fresh for 10-12 hours.',
  },
  {
    id: 'office-sensitive',
    text: 'Activity: Office/desk work. Concern: All-day freshness. Skin type: Sensitive.',
    recommendation: 'ODORSTRIKE 50ml — the Niacinamide + Aloe combo is built for sensitive skin. One morning application keeps you neutral through any office day. No irritation guaranteed.',
  },
  {
    id: 'outdoor-combination',
    text: 'Activity: Outdoor fieldwork. Concern: Underarms. Skin type: Combination.',
    recommendation: 'ODORSTRIKE 50ml — outdoor heat is where Zinc Ricinoleate proves itself. Unlike deodorants that fail in 30°C+, ODORSTRIKE neutralises odour chemically. Reapply midday if needed.',
  },
  {
    id: 'mixed-dry',
    text: 'Activity: Mixed daily. Concern: Post-sweat reapply. Skin type: Dry.',
    recommendation: 'ODORSTRIKE 50ml — Panthenol + Glycerin keeps your dry skin hydrated while the antibacterial base handles odour. Carry it in your bag for midday reapplication.',
  },
];

async function seed() {
  const index = pinecone.index(process.env.PINECONE_INDEX!);

  for (const profile of profiles) {
    const embeddingRes = await openai.embeddings.create({
      model: 'text-embedding-3-small',
      input: profile.text,
    });
    const vector = embeddingRes.data[0].embedding;

    await index.upsert([{
      id:       profile.id,
      values:   vector,
      metadata: { recommendation: profile.recommendation },
    }]);

    console.log(`✓ Seeded: ${profile.id}`);
  }
  console.log('Pinecone seed complete.');
}

seed().catch(console.error);
