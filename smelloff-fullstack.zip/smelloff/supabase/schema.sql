-- ════════════════════════════════════════
-- SMELLOFF / ODORSTRIKE — Supabase Schema
-- Run in Supabase Dashboard → SQL Editor
-- ════════════════════════════════════════

-- Waitlist
create table if not exists waitlist (
  id         uuid primary key default gen_random_uuid(),
  email      text unique not null,
  source     text default 'landing_page',
  created_at timestamptz default now()
);

-- Orders (populated by Stripe webhook)
create table if not exists orders (
  id                 uuid primary key default gen_random_uuid(),
  stripe_session_id  text unique not null,
  clerk_user_id      text,
  email              text,
  amount             numeric(10,2),
  currency           text default 'inr',
  status             text default 'paid',
  shipping_address   jsonb,
  created_at         timestamptz default now()
);

-- Row Level Security
alter table waitlist enable row level security;
alter table orders   enable row level security;

-- Service role bypasses RLS (used in API routes)
-- Anon users can insert into waitlist (for the form)
create policy "anon can join waitlist"
  on waitlist for insert
  to anon
  with check (true);

-- Authenticated users can view their own orders
create policy "user sees own orders"
  on orders for select
  using (clerk_user_id = current_setting('request.jwt.claims', true)::json->>'sub');

-- Indexes
create index if not exists waitlist_email_idx on waitlist(email);
create index if not exists orders_clerk_idx   on orders(clerk_user_id);
create index if not exists orders_email_idx   on orders(email);
