import { createClient } from '@supabase/supabase-js';

const supabaseUrl  = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
const serviceKey   = process.env.SUPABASE_SERVICE_ROLE_KEY!;

// Client-side (anon)
export const supabase = createClient(supabaseUrl, supabaseAnon);

// Server-side (service role — full access, server only)
export const supabaseAdmin = createClient(supabaseUrl, serviceKey);
