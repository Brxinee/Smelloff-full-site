import { Resend } from 'resend';

export const resend = new Resend(process.env.RESEND_API_KEY);

export async function sendWaitlistConfirmation(email: string) {
  return resend.emails.send({
    from: process.env.RESEND_FROM_EMAIL!,
    to: email,
    subject: 'You\'re on the ODORSTRIKE waitlist 🟢',
    html: `
      <div style="background:#0a0a0a;color:#f0f0f0;font-family:sans-serif;padding:48px;max-width:600px;margin:0 auto;">
        <h1 style="font-size:48px;font-weight:800;text-transform:uppercase;letter-spacing:0.1em;color:#b8ff57;margin:0 0 8px;">
          YOU'RE IN.
        </h1>
        <p style="color:#888;font-size:14px;text-transform:uppercase;letter-spacing:0.3em;margin-bottom:32px;">
          ODORSTRIKE Waitlist Confirmed
        </p>
        <p style="color:#f0f0f0;line-height:1.7;margin-bottom:24px;">
          Pilot batch is 50 units. You'll get the first notification when stock drops — along with a launch discount and free shipping in Hyderabad.
        </p>
        <p style="color:#888;font-size:13px;border-top:1px solid #2e2e2e;padding-top:24px;margin-top:32px;">
          Smell Like You Mean It · smelloff.in
        </p>
      </div>
    `,
  });
}

export async function sendOrderConfirmation(email: string, orderData: {
  orderId: string;
  product: string;
  amount: number;
}) {
  return resend.emails.send({
    from: process.env.RESEND_FROM_EMAIL!,
    to: email,
    subject: `Order confirmed — ODORSTRIKE #${orderData.orderId}`,
    html: `
      <div style="background:#0a0a0a;color:#f0f0f0;font-family:sans-serif;padding:48px;max-width:600px;margin:0 auto;">
        <h1 style="font-size:36px;font-weight:800;text-transform:uppercase;letter-spacing:0.1em;color:#b8ff57;margin:0 0 8px;">
          ORDER CONFIRMED
        </h1>
        <p style="color:#888;font-size:14px;text-transform:uppercase;letter-spacing:0.3em;margin-bottom:32px;">
          #${orderData.orderId}
        </p>
        <div style="border:1px solid #2e2e2e;padding:24px;margin-bottom:24px;">
          <p style="color:#f0f0f0;margin:0 0 8px;">${orderData.product}</p>
          <p style="color:#b8ff57;font-size:24px;font-weight:700;margin:0;">₹${orderData.amount}</p>
        </div>
        <p style="color:#888;line-height:1.7;">
          We'll ship from Hyderabad within 2-3 business days and send you a tracking link.
        </p>
        <p style="color:#888;font-size:13px;border-top:1px solid #2e2e2e;padding-top:24px;margin-top:32px;">
          Questions? hello@smelloff.in · smelloff.in
        </p>
      </div>
    `,
  });
}
