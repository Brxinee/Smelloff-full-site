# ODORSTRIKE by Smelloff — Full Stack D2C

Complete Next.js 14 D2C store with every integration wired.

## Stack
| Layer | Service | Cost |
|-------|---------|------|
| Frontend + API | Next.js 14 on Vercel | Free |
| Auth | Clerk | Free |
| Database | Supabase (Postgres) | Free |
| Payments | Stripe | Free (2.9% per txn) |
| Email | Resend | Free (3k/mo) |
| AI Recommender | Pinecone + OpenAI | ~$0 at low volume |
| Domain | smelloff.in (GoDaddy) | ₹800/yr |

**Total monthly infra cost: ~$0** (until serious scale)

---

## Setup — Step by Step

### 1. Clone & install
```bash
git clone https://github.com/Brxinee/Smelloff-
cd Smelloff-
npm install
cp .env.example .env.local
```

### 2. Clerk (auth)
- Go to clerk.com → Create application
- Copy Publishable Key + Secret Key → `.env.local`

### 3. Supabase (database)
- Go to supabase.com → New project
- SQL Editor → paste contents of `supabase/schema.sql` → Run
- Copy URL + anon key + service role key → `.env.local`

### 4. Stripe (payments)
- Go to stripe.com → Create product "ODORSTRIKE 50ml" at ₹299
- Copy Price ID → `NEXT_PUBLIC_PRODUCT_PRICE_ID` in `.env.local`
- Copy keys → `.env.local`
- After Vercel deploy: Stripe Dashboard → Webhooks → Add endpoint
  - URL: `https://smelloff.in/api/webhook`
  - Events: `checkout.session.completed`

### 5. Resend (email)
- Go to resend.com → Get API key
- Add domain `smelloff.in` → verify DNS
- Copy key → `.env.local`

### 6. Pinecone + OpenAI (AI recommender)
- Go to pinecone.io → Create index named `smelloff-products` (dimension: 1536)
- Go to platform.openai.com → Get API key
- Copy both keys → `.env.local`
- Seed Pinecone once: `npx ts-node scripts/seed-pinecone.ts`

### 7. Deploy to Vercel
```bash
# Push to GitHub first
git add . && git commit -m "initial" && git push

# Then in Vercel:
# 1. Import GitHub repo
# 2. Add all .env.local vars in Vercel dashboard
# 3. Deploy — done
```

### 8. DNS (GoDaddy → Vercel)
- In Vercel: Settings → Domains → Add `smelloff.in`
- In GoDaddy: DNS → Add CNAME `76.76.21.21` (Vercel IP)

---

## Project Structure
```
app/
  page.tsx              — Landing page
  shop/page.tsx         — Product + checkout
  account/page.tsx      — Order history (auth protected)
  success/page.tsx      — Post-purchase
  api/
    waitlist/route.ts   — Email capture → Supabase + Resend
    checkout/route.ts   — Stripe checkout session
    webhook/route.ts    — Stripe webhook → save order + email
    recommend/route.ts  — Pinecone AI recommender
components/
  Navbar.tsx            — Clerk auth buttons
  Hero.tsx              — Landing hero
  Benefits.tsx          — Ingredient benefits grid
  ComparisonTable.tsx   — vs competitors
  AIRecommender.tsx     — 3-question AI flow
  WaitlistSection.tsx   — Email capture
  Footer.tsx
lib/
  supabase.ts           — DB client
  stripe.ts             — Stripe client
  resend.ts             — Email templates
supabase/
  schema.sql            — Run in Supabase SQL editor
scripts/
  seed-pinecone.ts      — One-time AI knowledge seed
```
